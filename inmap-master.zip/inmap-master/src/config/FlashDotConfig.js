export default {
    style: {
        normal: {
            fps: 25, //动画帧数
            color: '#FAFA32',
            radius: 20, //动画半径范围
            speed: 0.15 //动画速度
        }
    },
    data: []
};