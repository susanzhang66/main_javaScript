export default {
    style: {
        normal: {
            borderColor: 'rgba(50, 50, 255, 0.8)',
            borderWidth: 0.05,
        },
    },
    data: [],
    event: {
        onState() {

        }
    }
};