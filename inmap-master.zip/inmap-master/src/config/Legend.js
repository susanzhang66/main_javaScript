export default {
    show: false,
    title: null,
    formatter: null,
    list: []
};