/**
 * 默认inmap 默认
 */
export default {
    center: [],
    id: null,
    skin: null, //Blueness WhiteLover
    zoom: {
        value: 5,
        show: true,
        max: 18,
        min: 5
    }
};